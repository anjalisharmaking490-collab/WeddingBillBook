package com.weddingbillbook.app

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.*

private val Navy = Color(0xFF071A2D)
private val Gold = Color(0xFFD4AF37)
private val Ink = Color(0xFF111111)
private val Rupee = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
private val DateFmt = DateTimeFormatter.ofPattern("dd MMM yyyy")

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDb
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db = AppDb(this); setContent { WeddingApp(db, this) } }
}

data class Booking(
    val id: Long = 0, val invoice: String, val client: String, val mobile: String, val address: String, val email: String,
    val bookingDate: String, val eventDate: String, val eventName: String, val packageName: String,
    val services: String, val total: Double, val advance: Double, val paymentMode: String, val remarks: String, val terms: String
) { val balance get() = total - advance }

data class Studio(val name:String="", val tagline:String="Wedding Photography & Cinematography", val mobile:String="", val address:String="", val email:String="", val instagram:String="", val facebook:String="")

class AppDb(private val c: Context) {
    private val h = c.openOrCreateDatabase("wedding_bill_book.db", Context.MODE_PRIVATE, null)
    init { h.execSQL("CREATE TABLE IF NOT EXISTS bookings(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice TEXT, client TEXT, mobile TEXT, address TEXT, email TEXT, bookingDate TEXT, eventDate TEXT, eventName TEXT, packageName TEXT, services TEXT, total REAL, advance REAL, paymentMode TEXT, remarks TEXT, terms TEXT)")
        h.execSQL("CREATE TABLE IF NOT EXISTS studio(id INTEGER PRIMARY KEY CHECK(id=1), name TEXT, tagline TEXT, mobile TEXT, address TEXT, email TEXT, instagram TEXT, facebook TEXT)") }
    fun all(): List<Booking> { val x=mutableListOf<Booking>(); h.rawQuery("SELECT * FROM bookings ORDER BY eventDate",null).use{ while(it.moveToNext()) x+=read(it)}; return x }
    fun byId(id:Long):Booking? = h.rawQuery("SELECT * FROM bookings WHERE id=?",arrayOf(id.toString())).use{if(it.moveToFirst())read(it) else null}
    fun save(b:Booking):Long { val v=android.content.ContentValues().apply{put("invoice",b.invoice);put("client",b.client);put("mobile",b.mobile);put("address",b.address);put("email",b.email);put("bookingDate",b.bookingDate);put("eventDate",b.eventDate);put("eventName",b.eventName);put("packageName",b.packageName);put("services",b.services);put("total",b.total);put("advance",b.advance);put("paymentMode",b.paymentMode);put("remarks",b.remarks);put("terms",b.terms)}; return if(b.id==0L)h.insert("bookings",null,v) else {h.update("bookings",v,"id=?",arrayOf(b.id.toString()));b.id} }
    fun delete(id:Long){h.delete("bookings","id=?",arrayOf(id.toString()))}
    fun nextInvoice():String { val n=h.rawQuery("SELECT COUNT(*) FROM bookings",null).use{it.moveToFirst();it.getInt(0)+1}; return "WB-%04d".format(n) }
    fun getStudio():Studio { h.rawQuery("SELECT * FROM studio WHERE id=1",null).use{if(it.moveToFirst())return Studio(it.s(1),it.s(2),it.s(3),it.s(4),it.s(5),it.s(6),it.s(7))}; return Studio() }
    fun saveStudio(s:Studio){val v=android.content.ContentValues().apply{put("id",1);put("name",s.name);put("tagline",s.tagline);put("mobile",s.mobile);put("address",s.address);put("email",s.email);put("instagram",s.instagram);put("facebook",s.facebook)};h.insertWithOnConflict("studio",null,v,android.database.sqlite.SQLiteDatabase.CONFLICT_REPLACE)}
    private fun read(c:android.database.Cursor)=Booking(c.l(0),c.s(1),c.s(2),c.s(3),c.s(4),c.s(5),c.s(6),c.s(7),c.s(8),c.s(9),c.s(10),c.d(11),c.d(12),c.s(13),c.s(14),c.s(15))
    private fun android.database.Cursor.s(i:Int)=getString(i); private fun android.database.Cursor.l(i:Int)=getLong(i); private fun android.database.Cursor.d(i:Int)=getDouble(i)
}

@Composable fun WeddingApp(db:AppDb, ctx:Context){
    var tab by remember{mutableIntStateOf(0)}; var selected by remember{mutableStateOf<Booking?>(null)}; var editing by remember{mutableStateOf<Booking?>(null)}; var refresh by remember{mutableIntStateOf(0)}
    MaterialTheme(colorScheme=darkColorScheme(primary=Gold,background=Navy,surface=Color(0xFF10253B),onPrimary=Ink,onBackground=Color.White,onSurface=Color.White)){
        Scaffold(bottomBar={NavigationBar(containerColor=Navy){ listOf(Icons.Default.CalendarMonth to "Calendar",Icons.Default.List to "Bookings",Icons.Default.AddCircle to "Add",Icons.Default.Settings to "Studio").forEachIndexed{ i,p->NavigationBarItem(selected=tab==i,onClick={tab=i;selected=null;editing=null},icon={Icon(p.first,null)},label={Text(p.second)})}}}){ pad->
            Box(Modifier.padding(pad).fillMaxSize().background(Navy)){
                when{selected!=null->BookingDetails(selected!!,db,ctx,{selected=null;refresh++},{editing=it;selected=null},{selected=null;refresh++})
                    editing!=null->BookingForm(db,editing, {editing=null;tab=0;refresh++})
                    tab==0->CalendarScreen(db,refresh,{selected=it},{tab=2})
                    tab==1->BookingsScreen(db,refresh,{selected=it})
                    tab==2->BookingForm(db,null,{tab=0;refresh++})
                    else->StudioScreen(db)
                }
            }
        }
    }
}

@Composable fun Header(title:String, back:(()->Unit)?=null){Row(Modifier.fillMaxWidth().background(Navy).padding(16.dp),verticalAlignment=Alignment.CenterVertically){if(back!=null){IconButton(back){Icon(Icons.Default.ArrowBack,"Back",tint=Gold)}};Text(title,Modifier.weight(1f),fontSize=22.sp,fontWeight=FontWeight.Bold,color=Color.White)}}
@Composable fun GoldButton(text:String,onClick:()->Unit,modifier:Modifier=Modifier){Button(onClick,modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Ink),shape=RoundedCornerShape(10.dp)){Text(text,fontWeight=FontWeight.Bold)}}
@Composable fun Field(label:String,value:String,onChange:(String)->Unit,modifier:Modifier=Modifier,number:Boolean=false){OutlinedTextField(value,onChange,label={Text(label)},modifier=modifier.fillMaxWidth(),singleLine=false,keyboardOptions=androidx.compose.foundation.text.KeyboardOptions(keyboardType=if(number)androidx.compose.ui.text.input.KeyboardType.Number else androidx.compose.ui.text.input.KeyboardType.Text))}

@Composable fun CalendarScreen(db:AppDb,refresh:Int,onOpen:(Booking)->Unit,onAdd:()->Unit){
    var ym by remember{mutableStateOf(YearMonth.now())}; var picked by remember{mutableStateOf(LocalDate.now())}
    val bookings=db.all(); val byDate=bookings.groupBy{it.eventDate}
    Column(Modifier.fillMaxSize()){
        Header("Wedding Bill Book")
        Row(Modifier.fillMaxWidth().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically){
            IconButton({ym=ym.minusMonths(1)}){Icon(Icons.Default.ChevronLeft,"Prev",tint=Gold)}
            Text(ym.month.name.lowercase().replaceFirstChar{it.uppercase()}+" "+ym.year,Modifier.weight(1f),textAlign=androidx.compose.ui.text.style.TextAlign.Center,fontSize=21.sp,fontWeight=FontWeight.Bold)
            IconButton({ym=ym.plusMonths(1)}){Icon(Icons.Default.ChevronRight,"Next",tint=Gold)}
        }
        Row(Modifier.padding(horizontal=8.dp).fillMaxWidth()){listOf("MON","TUE","WED","THU","FRI","SAT","SUN").forEach{Text(it,Modifier.weight(1f),fontSize=11.sp,textAlign=androidx.compose.ui.text.style.TextAlign.Center,color=Gold)}}
        val first=ym.atDay(1).dayOfWeek.value-1; val days=ym.lengthOfMonth(); val cells=(0 until first).map{0}+(1..days).toList()
        Column(Modifier.padding(8.dp)){for(row in cells.chunked(7)){Row(Modifier.fillMaxWidth()){for(v in row){Box(Modifier.weight(1f).padding(3.dp).height(48.dp).background(if(v>0&&byDate[ym.atDay(v).toString()].orEmpty().isNotEmpty())Gold.copy(.25f) else Color(0xFF10253B),RoundedCornerShape(8.dp)).clickable(enabled=v>0){if(v>0){picked=ym.atDay(v);byDate[picked.toString()]?.firstOrNull()?.let(onOpen)}},contentAlignment=Alignment.Center){if(v>0)Column(horizontalAlignment=Alignment.CenterHorizontally){Text(v.toString(),fontWeight=FontWeight.Bold);if(byDate[ym.atDay(v).toString()].orEmpty().isNotEmpty())Text(byDate[ym.atDay(v).toString()].size.toString(),fontSize=10.sp,color=Gold)}}}}}}
        Text("Bookings on ${picked.format(DateFmt)}",Modifier.padding(16.dp,8.dp),fontWeight=FontWeight.Bold,color=Gold)
        LazyColumn(Modifier.weight(1f)){items(byDate[picked.toString()].orEmpty()){BookingCard(it,onOpen)}}
        GoldButton("+ ADD CLIENT / NEW BOOKING",onAdd,Modifier.padding(16.dp))
    }
}

@Composable fun BookingCard(b:Booking,onOpen:(Booking)->Unit){Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=4.dp).clickable{onOpen(b)},colors=CardDefaults.cardColors(containerColor=Color(0xFF10253B))){Column(Modifier.padding(14.dp)){Text(b.client,fontWeight=FontWeight.Bold,fontSize=18.sp);Text("${b.eventDate} • ${b.eventName}");Text("${b.invoice}   ${money(b.total)}   Balance ${money(b.balance)}",color=Gold)}}}

@Composable fun BookingsScreen(db:AppDb,refresh:Int,onOpen:(Booking)->Unit){var q by remember{mutableStateOf("")};val list=db.all().filter{q.isBlank()||it.client.contains(q,true)||it.mobile.contains(q)||it.invoice.contains(q,true)||it.eventDate.contains(q)};Column{Header("All Bookings");Field("Search client / mobile / invoice / date",q,{q=it},Modifier.padding(16.dp));LazyColumn{items(list){BookingCard(it,onOpen)};if(list.isEmpty())item{Text("No bookings found",Modifier.padding(24.dp),color=Color.LightGray)}}}}

@Composable fun BookingForm(db:AppDb,existing:Booking?,done:()->Unit){val old=existing;var client by remember{mutableStateOf(old?.client? : "")};var mobile by remember{mutableStateOf(old?.mobile? : "")};var address by remember{mutableStateOf(old?.address? : "")};var email by remember{mutableStateOf(old?.email? : "")};var eventDate by remember{mutableStateOf(old?.eventDate? : LocalDate.now().toString())};var eventName by remember{mutableStateOf(old?.eventName? : "Wedding")};var pkg by remember{mutableStateOf(old?.packageName? : "")};var services by remember{mutableStateOf(old?.services? : "")};var total by remember{mutableStateOf(old?.total?.toString()?:"0")};var advance by remember{mutableStateOf(old?.advance?.toString()?:"0")};var mode by remember{mutableStateOf(old?.paymentMode?:"")};var remarks by remember{mutableStateOf(old?.remarks?:"")};var terms by remember{mutableStateOf(old?.terms?:defaultTerms())};val serviceNames=listOf("Photography","Videography","Cinematography","Drone Shoot","Pre-Wedding Shoot","12×36 Smart Album","Extra Hours / Days","Other");val selected=services.split("|").filter{it.isNotBlank()}.toMutableSet();Column(Modifier.verticalScroll(rememberScrollState())){Header(if(old==null)"Add Client / New Booking" else "Edit Booking");Field("Client Name *",client,{client=it},Modifier.padding(16.dp,8.dp));Field("Mobile Number *",mobile,{mobile=it},Modifier.padding(16.dp,8.dp),true);Field("Address",address,{address=it},Modifier.padding(16.dp,8.dp));Field("Email",email,{email=it},Modifier.padding(16.dp,8.dp));Field("Event / Wedding Date (YYYY-MM-DD) *",eventDate,{eventDate=it},Modifier.padding(16.dp,8.dp));Field("Function / Event",eventName,{eventName=it},Modifier.padding(16.dp,8.dp));Text("SELECT PACKAGE",Modifier.padding(16.dp,8.dp),fontWeight=FontWeight.Bold,color=Gold);Row(Modifier.padding(horizontal=16.dp)){listOf("Traditional","Cinematic").forEach{p->FilterChip(selected=pkg.contains(p),onClick={pkg=if(pkg.contains(p))pkg.replace(p,"").trim('|') else listOf(pkg,p).filter{it.isNotBlank()}.joinToString("|")},label={Text(p)},modifier=Modifier.padding(end=8.dp))}}
    Text("SERVICES / ITEMS",Modifier.padding(16.dp,12.dp),fontWeight=FontWeight.Bold,color=Gold);serviceNames.forEach{n->Row(Modifier.fillMaxWidth().clickable{if(selected.contains(n))selected.remove(n)else selected.add(n);services=selected.joinToString("|")}.padding(horizontal=16.dp,4.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(selected.contains(n),{if(selected.contains(n))selected.remove(n)else selected.add(n);services=selected.joinToString("|")});Text(n)}}
    Field("Total Amount (₹)",total,{total=it},Modifier.padding(16.dp,8.dp),true);Field("Advance Paid (₹)",advance,{advance=it},Modifier.padding(16.dp,8.dp),true);Text("Balance: ${money((total.toDoubleOrNull()?:0.0)-(advance.toDoubleOrNull()?:0.0))}",Modifier.padding(horizontal=16.dp),fontWeight=FontWeight.Bold,color=Gold);Text("PAYMENT MODE",Modifier.padding(16.dp,12.dp),fontWeight=FontWeight.Bold,color=Gold);Row(Modifier.padding(horizontal=16.dp)){listOf("Cash","UPI","Bank Transfer","Other").forEach{m->FilterChip(mode==m,{mode=m},{Text(m)},modifier=Modifier.padding(end=4.dp))}};Field("Remarks",remarks,{remarks=it},Modifier.padding(16.dp,8.dp));Field("Terms & Conditions",terms,{terms=it},Modifier.padding(16.dp,8.dp));Spacer(Modifier.height(8.dp));GoldButton(if(old==null)"SAVE BOOKING" else "UPDATE BOOKING",{if(client.isBlank()||mobile.isBlank()||eventDate.isBlank()){return@GoldButton};val b=Booking(old?.id?:0,old?.invoice?.takeIf{it.isNotBlank()}?:db.nextInvoice(),client,mobile,address,email,LocalDate.now().toString(),eventDate,eventName,pkg,services,total.toDoubleOrNull()?:0.0,advance.toDoubleOrNull()?:0.0,mode,remarks,terms);db.save(b);done()},Modifier.padding(16.dp));Spacer(Modifier.height(32.dp))}}

@Composable fun BookingDetails(b:Booking,db:AppDb,ctx:Context,back:()->Unit,edit:(Booking)->Unit,deleted:()->Unit){val s=db.getStudio();Column(Modifier.verticalScroll(rememberScrollState())){Header("Booking Details",back);InfoCard("CLIENT INFORMATION",listOf("Name" to b.client,"Mobile" to b.mobile,"Address" to b.address,"Email" to b.email));InfoCard("BOOKING INFORMATION",listOf("Invoice" to b.invoice,"Booking Date" to b.bookingDate,"Event Date" to b.eventDate,"Function" to b.eventName));InfoCard("PACKAGE",listOf("Package" to b.packageName.replace("|",", ")));InfoCard("SERVICES / ITEMS",b.services.split("|").filter{it.isNotBlank()}.mapIndexed{i,v->"${i+1}." to v});InfoCard("PAYMENT",listOf("Total" to money(b.total),"Advance" to money(b.advance),"Balance" to money(b.balance),"Mode" to b.paymentMode,"Remarks" to b.remarks));InfoCard("TERMS & CONDITIONS",listOf("" to b.terms));Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({edit(b)},Modifier.weight(1f)){Text("EDIT")};Button({generatePdf(ctx,b,s)},Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Gold,contentColor=Ink)){Text("PDF")}};Row(Modifier.padding(horizontal=16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({sharePdf(ctx,b,s)},Modifier.weight(1f)){Text("SHARE PDF")};Button({AlertDialog.Builder(ctx).setTitle("Delete booking?").setMessage("Are you sure you want to delete this booking?").setNegativeButton("CANCEL",null).setPositiveButton("DELETE"){_,_->db.delete(b.id);deleted()}.show()},Modifier.weight(1f),colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF8B1E1E))){Text("DELETE")}};Spacer(Modifier.height(30.dp))}}

@Composable fun InfoCard(title:String,rows:List<Pair<String,String>>){Card(Modifier.fillMaxWidth().padding(10.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF10253B))){Column(Modifier.padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,color=Gold);rows.forEach{if(it.first.isNotBlank())Text("${it.first}: ${it.second}",Modifier.padding(top=5.dp))else Text(it.second,Modifier.padding(top=8.dp))}}}}

@Composable fun StudioScreen(db:AppDb){var s by remember{mutableStateOf(db.getStudio())};var saved by remember{mutableStateOf(false)};Column(Modifier.verticalScroll(rememberScrollState())){Header("Studio Profile & Settings");var name by remember(s){mutableStateOf(s.name)};var tag by remember(s){mutableStateOf(s.tagline)};var mob by remember(s){mutableStateOf(s.mobile)};var addr by remember(s){mutableStateOf(s.address)};var email by remember(s){mutableStateOf(s.email)};var insta by remember(s){mutableStateOf(s.instagram)};var fb by remember(s){mutableStateOf(s.facebook)};Field("Studio Name",name,{name=it},Modifier.padding(16.dp,8.dp));Field("Tagline",tag,{tag=it},Modifier.padding(16.dp,8.dp));Field("Mobile",mob,{mob=it},Modifier.padding(16.dp,8.dp),true);Field("Address",addr,{addr=it},Modifier.padding(16.dp,8.dp));Field("Email",email,{email=it},Modifier.padding(16.dp,8.dp));Field("Instagram ID",insta,{insta=it},Modifier.padding(16.dp,8.dp));Field("Facebook / Social",fb,{fb=it},Modifier.padding(16.dp,8.dp));GoldButton("SAVE STUDIO PROFILE",{s=Studio(name,tag,mob,addr,email,insta,fb);db.saveStudio(s);saved=true},Modifier.padding(16.dp));if(saved)Text("Studio profile saved. It will appear on generated PDFs.",Modifier.padding(16.dp),color=Gold);Text("Default terms can be edited from the Terms field while creating a booking in this version.",Modifier.padding(16.dp),color=Color.LightGray)}}

fun defaultTerms()="1. Booking confirmation requires advance payment as agreed at the time of booking.\n2. Remaining payment shall be paid according to the agreed payment schedule.\n3. Final delivery will follow the agreed package and delivery schedule.\n4. Package details and coverage will be as agreed at the time of booking."
fun money(v:Double)=Rupee.format(v).replace("₹0.00","₹0")

fun generatePdf(ctx:Context,b:Booking,s:Studio):File{val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val c=page.canvas;val p=Paint(Paint.ANTI_ALIAS_FLAG);p.color=android.graphics.Color.BLACK;p.typeface=Typeface.DEFAULT;fun t(x:String,y:Float,size:Float,bold:Boolean=false){p.textSize=size;p.typeface=if(bold)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;c.drawText(x.take(85),35f,y,p)};p.color=android.graphics.Color.rgb(7,26,45);c.drawRect(0f,0f,595f,105f,p);p.color=android.graphics.Color.WHITE;t(s.name.ifBlank{"Wedding Bill Book"},42f,25f,true);t(s.tagline,66f,12f);t("${s.mobile}  ${s.instagram}",88f,11f);p.color=android.graphics.Color.rgb(212,175,55);c.drawRect(0f,105f,595f,110f,p);p.color=android.graphics.Color.BLACK;t("CLIENT INFORMATION",138f,13f,true);t("Name: ${b.client}",160f,11f);t("Mobile: ${b.mobile}",178f,11f);t("Address: ${b.address}",196f,11f);t("Email: ${b.email}",214f,11f);t("BOOKING INFORMATION",245f,13f,true);t("Invoice: ${b.invoice}",267f,11f);t("Booking Date: ${b.bookingDate}",285f,11f);t("Event Date: ${b.eventDate}",303f,11f);t("Function: ${b.eventName}",321f,11f);t("Package: ${b.packageName.replace("|",", ")}",339f,11f);p.color=android.graphics.Color.BLACK;c.drawRect(30f,355f,565f,380f,p);p.color=android.graphics.Color.WHITE;t("S.No.   SERVICES / ITEMS                                      AMOUNT",373f,10f,true);p.color=android.graphics.Color.BLACK;var y=400f;b.services.split("|").filter{it.isNotBlank()}.forEachIndexed{ i, v ->t("${i+1}      $v",y,11f);y+=20}};y+=10;t("TOTAL AMOUNT: ${money(b.total)}",y,14f,true);y+=22;t("ADVANCE PAID: ${money(b.advance)}",y,12f);y+=22;t("BALANCE AMOUNT: ${money(b.balance)}",y,13f,true);y+=32;t("PAYMENT MODE: ${b.paymentMode}",y,11f);y+=22;t("REMARKS: ${b.remarks}",y,10f);y+=28;t("TERMS & CONDITIONS",y,13f,true);y+=18;b.terms.split("\n").take(6).forEach{t(it,y,9f);y+=16};y=760f;t("Customer Signature",y,10f);t("Authorized Signature",y,10f);p.color=android.graphics.Color.rgb(7,26,45);c.drawRect(0f,805f,595f,842f,p);p.color=android.graphics.Color.WHITE;t("${s.name}   |   ${s.mobile}   |   ${s.instagram}",828f,10f,true);doc.finishPage(page);val dir=File(ctx.getExternalFilesDir(null),"bills").apply{mkdirs()};val file=File(dir,"WeddingBill_${b.client.replace(" ","_")}_${b.invoice}.pdf");FileOutputStream(file).use{doc.writeTo(it)};doc.close();return file}
fun sharePdf(ctx:Context,b:Booking,s:Studio){val f=generatePdf(ctx,b,s);val uri=androidx.core.content.FileProvider.getUriForFile(ctx,"com.weddingbillbook.app.fileprovider",f);val i=Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)};ctx.startActivity(Intent.createChooser(i,"Share bill PDF"))}
