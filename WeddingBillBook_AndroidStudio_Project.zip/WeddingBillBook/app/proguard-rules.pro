# Wedding Bill Book - no custom rules required for v1
