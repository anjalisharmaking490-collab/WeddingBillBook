# Wedding Bill Book

Android Studio project for an offline wedding photography/cinematography booking and bill app.

## Included in v1
- Calendar dashboard with booking indicators
- Client + booking form
- Traditional/Cinematic package selection
- Service selection
- Total / advance / balance calculation
- Invoice numbering (`WB-0001` style)
- Local SQLite storage (no server required)
- Search by client, mobile, invoice or date
- Booking details, edit and delete
- Studio profile
- A4 PDF generation using Android `PdfDocument`
- Android Sharesheet PDF sharing (WhatsApp can be selected if installed)
- Dark blue / gold / white / black visual theme

## Open in Android Studio
1. Open the `WeddingBillBook` folder.
2. Let Android Studio download the Gradle distribution/dependencies.
3. Run on an Android phone/emulator.
4. Build > Build APK(s) for a debug APK.

The uploaded bill image is used only as the visual design reference. Do not ship the reference studio's personal contact information; enter your own Studio Profile in the app.

## Important
The current project intentionally uses platform SQLite and `PdfDocument` to keep the dependency footprint small. For a production release, add automated database migrations, backup/restore encryption, a real signature pad, logo picker/storage, and stronger PDF layout matching after final visual approval.
