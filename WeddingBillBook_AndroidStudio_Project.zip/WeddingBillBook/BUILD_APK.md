# Build the APK

## Android Studio
Open this folder in Android Studio, wait for Gradle sync, then use:
**Build > Build APK(s)**.

The debug APK will be under:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub (no Android Studio required)
1. Create a new GitHub repository.
2. Upload this entire project.
3. Push to `main`, or open **Actions > Build Wedding Bill Book APK > Run workflow**.
4. Open the completed workflow run.
5. Download the `WeddingBillBook-debug-apk` artifact.

A signed Play Store release should be generated later with a private signing key; do not put that key in GitHub source.
